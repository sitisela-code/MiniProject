import java.util.ArrayList;

public class Transaksi {
    private String noTransaksi; // nomor unik buat transaksi
    private ArrayList<Produk> daftarProduk; // daftar barang yang dibeli

    // constructor: bikin transaksi baru dengan nomor tertentu
    public Transaksi(String noTransaksi) {
        this.noTransaksi = noTransaksi;
        daftarProduk = new ArrayList<>(); // mulai dengan list kosong
    }

    // fungsi buat nambahin produk ke daftar belanja
    public void tambahProduk(Produk p) {
        daftarProduk.add(p);
    }

    // hitung total belanja, kalau produknya ada diskon, pakai harga diskon
    public double hitungTotal() {
        double total = 0;
        for (Produk p : daftarProduk) {
            if (p instanceof ProdukDiskon) {
                ProdukDiskon pd = (ProdukDiskon) p;
                total += pd.hitungHargaDiskon(); // kalau produk diskon, pakai harga setelah diskon
            } else {
                total += p.getHarga(); // kalau produk biasa, langsung ambil harga normal
            }
        }
        return total;
    }

    // cetak struk belanja biar kelihatan rapi
    public void cetakStruk() {
        System.out.println("===== STRUK BELANJA =====");
        System.out.println("No Transaksi: " + noTransaksi);

        // tampilkan semua produk yang ada di daftar
        for (Produk p : daftarProduk) {
            p.tampil();
        }

        System.out.println("--------------------------");
        System.out.println("Total: Rp " + hitungTotal()); // total belanjaan
    }
}
