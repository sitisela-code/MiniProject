public class Main {
    public static void main(String[] args) {

        // Produk biasa
        Produk p1 = new Produk("P001", "Beras", 12000);
        Produk p2 = new Produk("P002", "Gula", 10000);

        // Produk diskon
        ProdukDiskon d1 = new ProdukDiskon("P003", "Minyak", 15000, 10);
        ProdukDiskon d2 = new ProdukDiskon("P004", "Susu", 20000, 20);

        // Transaksi
        Transaksi t = new Transaksi("TRX001");

        t.tambahProduk(p1);
        t.tambahProduk(p2);
        t.tambahProduk(d1);
        t.tambahProduk(d2);

        t.cetakStruk();
    }
}