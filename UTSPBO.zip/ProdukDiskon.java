public class ProdukDiskon extends Produk {
    private double diskon; // persen diskon yang berlaku untuk produk ini

    // constructor: bikin produk diskon dengan kode, nama, harga, dan besar diskon
    public ProdukDiskon(String kode, String nama, double harga, double diskon) {
        super(kode, nama, harga); // panggil constructor dari Produk (parent class)
        this.diskon = diskon;
    }

    // ambil nilai diskon
    public double getDiskon() {
        return diskon;
    }

    // ubah nilai diskon kalau perlu
    public void setDiskon(double diskon) {
        this.diskon = diskon;
    }

    // hitung harga setelah diskon, rumusnya harga - (harga * diskon / 100)
    public double hitungHargaDiskon() {
        return getHarga() - (getHarga() * diskon / 100);
    }

    // tampilkan info produk di struk: kode, nama, harga asli, diskon, dan harga akhir
    @Override
    public void tampil() {
        System.out.println(getKode() + " - " + getNama() +
                " : Rp " + getHarga() +
                " | Diskon: " + diskon + "%" +
                " | Harga Akhir: Rp " + hitungHargaDiskon());
    }
}
